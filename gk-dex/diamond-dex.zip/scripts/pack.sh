#!/usr/bin/env bash
echo test pack
docker build . --tag=coinexchain/cetdtest