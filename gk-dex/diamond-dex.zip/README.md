# Diamond DEX
A high performance public blockchain with built-in DEX based on Diamond Network SDK

[![Language](https://img.shields.io/badge/Language-Go-blue.svg)](https://golang.org/)

为去中心化交易所而打造的公链


* 秒级区块生成速度
* 资产，订单都保存在链上，完全透明
* 一键发布新资产
* 高性能交易引擎


# 如何编译

## 编译Rocksdb

### 安装编译需要的工具和依赖包

yum -y install epel-release
yum -y update
yum install -y gcc-c++ snappy snappy-devel zlib zlib-devel bzip2 bzip2-devel lz4-devel libzstd libzstd-devel gflags gflags-devel git

通过gcc --version显示的gcc版本必须在4.8以上，比如4.8.5

### 编译

直接通过git克隆RocksDB的代码，然后切换到5.18.4分支上编译动态库（因为最新的master分支用了最新的c++特性，机器自带的gcc 4.8不能编译通过）


git clone https://github.com/facebook/rocksdb.git
cd rocksdb
git checkout v5.18.4  
make shared_lib

### 复制RocksDB的so文件到系统目录，这样运行时就可以加载它们

cp librocksdb.so* /usr/lib
cp librocksdb.so* /usr/lib64

## 编译节点

### 安装Golang编译器


wget https://golang.org/dl/go1.15.2.linux-amd64.tar.gz
tar -C /usr/local -xzf go1.15.2.linux-amd64.tar.gz
export PATH=$PATH:/usr/local/go/bin



