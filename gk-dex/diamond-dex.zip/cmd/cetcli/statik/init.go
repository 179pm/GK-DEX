package statik

//This just for fixing the error in importing empty github.com/coinexchain/dex/cmd/cetcli/statik
