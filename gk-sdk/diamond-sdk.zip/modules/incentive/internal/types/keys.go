package types

const (
	ModuleName        = "incentive"
	QuerierRoute      = ModuleName
	DefaultParamspace = ModuleName
	RouterKey         = ModuleName
	StoreKey          = ModuleName
)
