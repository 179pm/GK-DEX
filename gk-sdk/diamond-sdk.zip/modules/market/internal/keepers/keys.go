package keepers

var (
	MarketIdentifierPrefix = []byte{0x15}
	DelistKey              = []byte{0x40}
	DelistRevKey           = []byte{0x42}
)
