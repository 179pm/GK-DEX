package simulation

const (
	letterBytes = "abcdefghijklmnopqrstuvwxyz"
)

const (
	SymbolLenth = 4
)
