package types

const (
	AttributeValueCategory = ModuleName

	EventTypeSetReferee = "set_referee"

	AttributeReferee           = "referee_addr"
	AttributeRefereeChangeTime = "referee_change_time"
)
