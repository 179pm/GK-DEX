package msgqueue

var (
	EventTypeMsgQueue = "kafka"
)
